<?php 

if (!defined('APP_VERSION')) die("Yo, what's up?"); 


// Return the config array
return [
    "idname" => "photoeditor",
    "plugin_name" => "Photo Editor",
    "author" => "Muhamad Kanhan",
    "author_uri" => "http://mybotgram.ga",
    "version" => "1.0.0",
    "desc" => "By Useing This Module You Can Edit Photos Free And Easy With Out Flash Player & Adobe",
    "icon_style" => "font-size: 18px;",
];
    