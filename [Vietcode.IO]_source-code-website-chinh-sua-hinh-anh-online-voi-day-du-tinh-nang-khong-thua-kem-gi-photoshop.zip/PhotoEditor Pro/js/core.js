/**
 * Module Namespace
 */
var photoeditorModule = {};


photoeditorModule.go = function() {
    
};