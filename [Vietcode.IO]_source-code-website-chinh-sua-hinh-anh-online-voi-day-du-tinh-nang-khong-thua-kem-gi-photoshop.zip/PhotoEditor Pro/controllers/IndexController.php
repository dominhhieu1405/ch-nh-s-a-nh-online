<?php
namespace Plugins\photoeditorModule;

// Disable direct access
if (!defined('APP_VERSION')) 
    die("Yo, what's up?");

/**
 * Index Controller
 */
class IndexController extends \Controller
{


    /**
     * Process
     */
    public function process()
    {
        
        //global vars
        $this->setVariable("idname", "photoeditor");
        $this->setVariable("baseUrl", APPURL."/e/".$this->getVariable('idname'));
        $this->setVariable("iframeUrl", "http://mybotgram.ga/picseditor/?");

        $AuthUser = $this->getVariable("AuthUser");
        $EmailSettings = \Controller::model("GeneralData", "email-settings");

        if (!$AuthUser){
            header("Location: ".APPURL."/login");
            exit;
        } else if (
            !$AuthUser->isAdmin() && 
            !$AuthUser->isEmailVerified() &&
            $EmailSettings->get("data.email_verification")) 
        {
            header("Location: ".APPURL."/profile?a=true");
            exit;
        } else if ($AuthUser->isExpired()) {
            header("Location: ".APPURL."/expired");
            exit;
        }



        // Get accounts
        $Accounts = \Controller::model("Accounts");
        $Accounts->where("user_id", "=", $AuthUser->get("id"))
                 ->orderBy("id","DESC")
                 ->fetchData();
        $this->setVariable("Accounts", $Accounts);


        // Get Active Account
        $ActiveAccount = \Controller::model("Account", \Input::get("account"));
        if (!$ActiveAccount->isAvailable() || 
            $ActiveAccount->get("user_id") != $AuthUser->get("id")) {
            
            $data = $Accounts->getDataAs("Account");
            if (isset($data[0])) {
                $ActiveAccount = $data[0];
            }
        }
      
        $this->setVariable("ActiveAccount", $ActiveAccount);

        $this->view(PLUGINS_PATH."/".$this->getVariable("idname")."/views/index.php", null);
    }


}