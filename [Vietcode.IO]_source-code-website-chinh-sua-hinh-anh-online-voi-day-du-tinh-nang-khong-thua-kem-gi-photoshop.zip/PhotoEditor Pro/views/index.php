<?php if (!defined('APP_VERSION')) die("Yo, what's up?");  ?>
<!DOCTYPE html>
<html lang="<?= ACTIVE_LANG ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="theme-color" content="#fff">

        <meta name="description" content="<?= site_settings("site_description") ?>">
        <meta name="keywords" content="<?= site_settings("site_keywords") ?>">

        <link rel="icon" href="<?= site_settings("logomark") ? site_settings("logomark") : APPURL."/assets/img/logomark.png" ?>" type="image/x-icon">
        <link rel="shortcut icon" href="<?= site_settings("logomark") ? site_settings("logomark") : APPURL."/assets/img/logomark.png" ?>" type="image/x-icon">

        <link rel="stylesheet" type="text/css" href="<?= APPURL."/assets/css/plugins.css?v=".VERSION ?>">
        <link rel="stylesheet" type="text/css" href="<?= APPURL."/assets/css/core.css?v=".VERSION ?>">

        <!-- Include custom CSS file for this module -->
        <link rel="stylesheet" type="text/css" href="<?= PLUGINS_URL."/photoeditor/assets/css/core.css?v=".VERSION ?>">

        <title><?= __("Photo Editor") ?></title>
    </head>

    <body>
        <?php 
		   
	

            $Nav = new stdClass;
            $Nav->activeMenu = "photoeditor";
            require_once(APPPATH.'/views/fragments/navigation.fragment.php');
        ?>

        <?php 
            $TopBar = new stdClass;
            $TopBar->title = __("Photo Editor");
            $TopBar->btn = false;
            require_once(APPPATH.'/views/fragments/topbar.fragment.php'); 
        ?>

        <?php require_once(__DIR__.'/fragments/photoeditor.fragment.php'); ?>
        
        <script type="text/javascript" src="<?= APPURL."/assets/js/plugins.js?v=".VERSION ?>"></script>
        <?php require_once(APPPATH.'/inc/js-locale.inc.php'); ?>
        <script type="text/javascript" src="<?= APPURL."/assets/js/core.js?v=".VERSION ?>"></script>

        <!-- Include custom JS file for this module -->
        <!-- Script que altera o tamanho do iframe de acordo com conteúdo da página -->
        <script type="text/javascript" charset="utf-8">

                  function calcHeight(iframeElement){
                      var the_height=  iframeElement.contentWindow.document.body.scrollHeight;
                      iframeElement.height =  the_height+150;
                  }
                    
                  function reloadiframe()
                    {
                      
                      var sel = document.getElementById("account");
                      var text = sel.options[sel.selectedIndex].text;
                      var urliframe = "<?= $iframeUrl ?>"+text;
                     
                      setTimeout(function(){ 
                        document.getElementById('framephotoeditor').src = urliframe;
                      }, 1000);
                      
                    }
                    
                    reloadiframe();
                    
            </script>

        <!-- GOOGLE ANALYTICS -->
        <?php require_once(APPPATH.'/views/fragments/google-analytics.fragment.php'); ?>
    </body>
</html>

