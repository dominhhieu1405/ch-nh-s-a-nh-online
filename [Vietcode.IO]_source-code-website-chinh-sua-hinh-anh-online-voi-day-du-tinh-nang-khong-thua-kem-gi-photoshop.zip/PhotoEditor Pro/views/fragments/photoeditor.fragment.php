        <div class="skeleton" id="photoeditor">
            <div class="container-1200">
                <div class="row clearfix">
                 <?php if ($Accounts->getTotalCount() > 0): ?>
                        <form action="<?= $baseUrl ?>" method="GET">
                            <div class="account-selector clearfix">
                                <span class="label"><?= __("Select Account") ?></span>

                                <select class="input input--small" name="account" id="account" onchange="reloadiframe()">
                                    <?php foreach ($Accounts->getData() as $a): ?>
                                        <option value="<?= $a->id ?>" <?= $a->id == $ActiveAccount->get("id") ? "selected" : "" ?>>
                                            <?= htmlchars($a->username); ?>
                                        </option>
                                    <?php endforeach ?>
                                </select>
                            </div>
</div>
                            <input class="none" type="submit" value="<?= __("Submit") ?>">
                        </form>


                    </br>
                  
                  
                  
                                   
                        
                                      
                                        <iframe id="framephotoeditor" name="framephotoeditor" src="" scrolling="yes"  onLoad="calcHeight(this);" frameborder="0" width="100%" height="550px"></iframe>
                                        </div>
                                    </div>
                                </section>
                            </div>
                          

                        </div>

                        
                    <?php else: ?>
                        <?php include APPPATH.'/views/fragments/noaccount.fragment.php'; ?>
                    <?php endif ?>
                </div>
            </div>
        </div>